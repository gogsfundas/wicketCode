package com.vinsys.app;

public class TeleVisionPage extends BasePage {

}
