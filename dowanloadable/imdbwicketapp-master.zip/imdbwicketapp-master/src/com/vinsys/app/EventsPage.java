package com.vinsys.app;

public class EventsPage extends BasePage {

}
