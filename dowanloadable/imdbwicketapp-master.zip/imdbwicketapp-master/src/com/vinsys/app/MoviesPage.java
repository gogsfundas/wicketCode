package com.vinsys.app;

public class MoviesPage extends BasePage {

}
