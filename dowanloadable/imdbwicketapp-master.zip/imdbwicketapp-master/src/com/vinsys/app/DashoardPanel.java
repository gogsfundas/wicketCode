package com.vinsys.app;

import org.apache.wicket.markup.html.panel.Panel;

public class DashoardPanel extends Panel {

	public DashoardPanel(String id) {
		super(id);
	}

}
