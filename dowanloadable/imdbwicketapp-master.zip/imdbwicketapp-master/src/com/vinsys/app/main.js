
(function(){
	console.log("This is cool")
})()