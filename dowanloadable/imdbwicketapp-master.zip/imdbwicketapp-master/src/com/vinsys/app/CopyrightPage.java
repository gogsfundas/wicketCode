package com.vinsys.app;

import org.apache.wicket.markup.html.WebPage;

public class CopyrightPage extends WebPage {

	public CopyrightPage() {
	}
}
