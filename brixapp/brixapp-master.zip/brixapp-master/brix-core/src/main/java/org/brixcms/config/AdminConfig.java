/**
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.brixcms.config;

public class AdminConfig {
// moved out into brix-cms-plugins project due to license incompatibility
// private boolean enableCodePress = true;
// private boolean enableWysiwyg = true;
//
// public boolean isEnableCodePress()
// {
// return enableCodePress;
// }
//
// public void setEnableCodePress(boolean enableCodePress)
// {
// this.enableCodePress = enableCodePress;
// }
//
// public boolean isEnableWysiwyg()
// {
// return enableWysiwyg;
// }
//
// public void setEnableWysiwyg(boolean enableWysiwyg)
// {
// this.enableWysiwyg = enableWysiwyg;
// }
}
